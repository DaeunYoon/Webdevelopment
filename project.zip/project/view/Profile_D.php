<div class="container" style="margin: 2rem;">
<form action="../controller/Profile_Delete.php" method="post">
    <label for="del">Confirm userID to delete : </label>
    <input type="text" name="del" id="del">&nbsp;
    <input type="submit" value="confirm">
</form>
</div>