<div class="container" style="margin: 2rem;">
<form action="../controller/Profile_Delete.php" method="post">
    <label for="del" id="deltxt">Confirm userID to delete : </label>
    <input type="text" name="del" id="del">&nbsp;
    <button id="delbtn"  type="submit" class="btn btn-danger">Confirm</button>
</form>
</div>
<script src="https://code.jquery.com/jquery-3.4.1.js"></script>
